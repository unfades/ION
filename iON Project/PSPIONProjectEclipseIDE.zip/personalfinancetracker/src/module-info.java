/**
 * 
 */
/**
 * 
 */
module personalfinancetracker {
	requires org.junit.jupiter.api;
}