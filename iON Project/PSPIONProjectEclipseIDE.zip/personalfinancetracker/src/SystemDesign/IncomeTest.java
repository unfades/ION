package SystemDesign;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.jupiter.api.Test;

class IncomeTest {

	@Test
	void testAccountIncomeInput() {
        BigDecimal amount = new BigDecimal("1000");
        Date d = new Date();
        String category = "c";
        Transaction t = new Income(amount, d.toString(), category);
        BigDecimal thousand = new BigDecimal("1000");
        assertEquals(thousand, t.amount);
    }
	
	@Test
	void testAccountIncomeDecimalAddition() {
		BigDecimal amount = new BigDecimal("0.1");
		Date d = new Date();
		String category = "c";
		Transaction t = new Income(amount, d.toString(), category);
		Account mine = new Account();
		mine.addTransaction(t);
		amount = new BigDecimal("0.2");
		t = new Income(amount, d.toString(), category);
		mine.addTransaction(t);
		assertEquals(new BigDecimal("0.3"), mine.getBalance());
	}
}
